var person = {
  name: "Bob",
  age: 25,
};
person.city = "New York";
console.log(person.city);
